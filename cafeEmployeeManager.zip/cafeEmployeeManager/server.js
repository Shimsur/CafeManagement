const express = require('express');
const connection = require('./db');
const app = express();
const port = 3000;

app.use(express.json());

// Get cafes endpoint
app.get('/cafes', (req, res) => {
    const location = req.query.location || '';
    const query = `SELECT * FROM cafes WHERE location LIKE ? ORDER BY (SELECT COUNT(*) FROM employees WHERE cafe_id = cafes.id) DESC`;
    connection.query(query, [`%${location}%`], (err, results) => {
        if (err) return res.status(500).send('Server Error');
        res.json(results);
    });
});

// Get employees endpoint
app.get('/employees', (req, res) => {
    const cafe = req.query.cafe || '';
    const query = `SELECT e.id, e.name, e.email_address, e.phone_number, DATEDIFF(CURDATE(), e.start_date) AS days_worked, c.name AS cafe FROM employees e LEFT JOIN cafes c ON e.cafe_id = c.id WHERE c.name LIKE ? ORDER BY days_worked DESC`;
    connection.query(query, [`%${cafe}%`], (err, results) => {
        if (err) return res.status(500).send('Server Error');
        res.json(results);
    });
});

// POST /cafe
app.post('/cafe', (req, res) => {
    const { name, description, logo, location } = req.body;
    const query = `INSERT INTO cafes (id, name, description, logo, location) VALUES (UUID(), ?, ?, ?, ?)`;
    connection.query(query, [name, description, logo, location], (err, results) => {
        if (err) return res.status(500).send('Server Error');
        res.status(201).send('Cafe Created');
    });
});

// POST /employee
app.post('/employee', (req, res) => {
    const { id, name, email_address, phone_number, gender, cafe_id, start_date } = req.body;
    const query = `INSERT INTO employees (id, name, email_address, phone_number, gender, cafe_id, start_date) VALUES (?, ?, ?, ?, ?, ?, ?)`;
    connection.query(query, [id, name, email_address, phone_number, gender, cafe_id, start_date], (err, results) => {
        if (err) return res.status(500).send('Server Error');
        res.status(201).send('Employee Created');
    });
});

// PUT /cafe
app.put('/cafe', (req, res) => {
    const { id, name, description, logo, location } = req.body;
    const query = `UPDATE cafes SET name = ?, description = ?, logo = ?, location = ? WHERE id = ?`;
    connection.query(query, [name, description, logo, location, id], (err, results) => {
        if (err) return res.status(500).send('Server Error');
        res.send('Cafe Updated');
    });
});

// PUT /employee
app.put('/employee', (req, res) => {
    const { id, name, email_address, phone_number, gender, cafe_id, start_date } = req.body;
    const query = `UPDATE employees SET name = ?, email_address = ?, phone_number = ?, gender = ?, cafe_id = ?, start_date = ? WHERE id = ?`;
    connection.query(query, [name, email_address, phone_number, gender, cafe_id, start_date, id], (err, results) => {
        if (err) return res.status(500).send('Server Error');
        res.send('Employee Updated');
    });
});

// DELETE /cafe
app.delete('/cafe', (req, res) => {
    const { id } = req.body;
    const query = `DELETE FROM cafes WHERE id = ?`;
    connection.query(query, [id], (err, results) => {
        if (err) return res.status(500).send('Server Error');
        res.send('Cafe Deleted');
    });
});

// DELETE /employee
app.delete('/employee', (req, res) => {
    const { id } = req.body;
    const query = `DELETE FROM employees WHERE id = ?`;
    connection.query(query, [id], (err, results) => {
        if (err) return res.status(500).send('Server Error');
        res.send('Employee Deleted');
    });
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
