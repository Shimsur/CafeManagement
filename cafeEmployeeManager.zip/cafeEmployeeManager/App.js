import React, { useState } from 'react';
import CafeForm from './components/CafeForm'; // Import CafeForm
import EmployeeForm from './components/EmployeeForm'; // Import EmployeeForm

function App() {
  // You can pass any data you need, like initial values or functions to handle form submission
  const [cafes, setCafes] = useState([]);
  const [employees, setEmployees] = useState([]);

  const handleSubmitCafe = (formData) => {
    // Make API call to POST or PUT the cafe data
    console.log('Submitting Cafe:', formData);
  };

  const handleSubmitEmployee = (formData) => {
    // Make API call to POST or PUT the employee data
    console.log('Submitting Employee:', formData);
  };

  return (
    <div className="App">
      <h1>Cafe and Employee Manager</h1>
      <CafeForm onSubmit={handleSubmitCafe} />
      <EmployeeForm cafes={cafes} onSubmit={handleSubmitEmployee} />
    </div>
  );
}

export default App;
