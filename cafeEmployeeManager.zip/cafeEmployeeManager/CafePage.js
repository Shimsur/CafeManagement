import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Button, TextField, Grid, Container, Typography } from '@mui/material';
import AgGridReact from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';

const CafesPage = () => {
  const [cafes, setCafes] = useState([]);
  const [location, setLocation] = useState('');
  const [newCafe, setNewCafe] = useState({
    name: '',
    description: '',
    location: '',
    logo: null,
  });
  const [isEditing, setIsEditing] = useState(false);
  const [editCafe, setEditCafe] = useState(null);
  
  // Fetch cafes on page load
  useEffect(() => {
    fetchCafes();
  }, []);

  const fetchCafes = async () => {
    try {
      const response = await axios.get(`/cafes?location=${location}`);
      setCafes(response.data);
    } catch (error) {
      console.error('Error fetching cafes:', error);
    }
  };

  // Handle changes in input fields
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewCafe((prevCafe) => ({
      ...prevCafe,
      [name]: value,
    }));
  };

  // Handle form submission for adding new cafe
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (newCafe.name && newCafe.description && newCafe.location) {
      try {
        if (isEditing) {
          await axios.put(`/cafe`, newCafe);
          setIsEditing(false);
        } else {
          await axios.post(`/cafe`, newCafe);
        }
        fetchCafes();
        setNewCafe({ name: '', description: '', location: '', logo: null });
      } catch (error) {
        console.error('Error creating/updating cafe:', error);
      }
    } else {
      alert('Please fill in all fields.');
    }
  };

  // Handle deleting a cafe
  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this cafe?')) {
      try {
        await axios.delete(`/cafe/${id}`);
        fetchCafes();
      } catch (error) {
        console.error('Error deleting cafe:', error);
      }
    }
  };

  // Handle filtering cafes based on location
  const handleLocationFilter = (e) => {
    setLocation(e.target.value);
    fetchCafes();
  };

  const handleEdit = (cafe) => {
    setNewCafe(cafe);
    setIsEditing(true);
    setEditCafe(cafe);
  };

  const columns = [
    { headerName: 'Logo', field: 'logo', cellRenderer: 'agGroupCellRenderer' },
    { headerName: 'Name', field: 'name' },
    { headerName: 'Description', field: 'description' },
    { headerName: 'Location', field: 'location' },
    { headerName: 'Employees', field: 'employees', sortable: true, filter: true },
    {
      headerName: 'Actions',
      cellRendererFramework: (params) => (
        <>
          <Button onClick={() => handleEdit(params.data)}>Edit</Button>
          <Button onClick={() => handleDelete(params.data.id)}>Delete</Button>
        </>
      ),
    },
  ];

  return (
    <Container>
      <Typography variant="h4" gutterBottom>
        Cafes Manager
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <TextField
            label="Filter by Location"
            value={location}
            onChange={handleLocationFilter}
            fullWidth
          />
        </Grid>

        <Grid item xs={12}>
          <Button variant="contained" color="primary" onClick={() => setIsEditing(false)}>
            Add New Cafe
          </Button>
        </Grid>
      </Grid>

      <div className="ag-theme-alpine" style={{ height: 400, width: '100%' }}>
        <AgGridReact
          columnDefs={columns}
          rowData={cafes}
          pagination={true}
          domLayout="autoHeight"
        />
      </div>

      <form onSubmit={handleSubmit}>
        <TextField
          label="Cafe Name"
          name="name"
          value={newCafe.name}
          onChange={handleInputChange}
          required
          fullWidth
        />
        <TextField
          label="Description"
          name="description"
          value={newCafe.description}
          onChange={handleInputChange}
          required
          fullWidth
        />
        <TextField
          label="Location"
          name="location"
          value={newCafe.location}
          onChange={handleInputChange}
          required
          fullWidth
        />
        {/* Logo upload input (optional) */}
        <input
          type="file"
          name="logo"
          accept="image/*"
          onChange={(e) => setNewCafe({ ...newCafe, logo: e.target.files[0] })}
        />
        <Button type="submit" variant="contained" color="primary">
          {isEditing ? 'Update Cafe' : 'Create Cafe'}
        </Button>
      </form>
    </Container>
  );
};

export default CafesPage;
