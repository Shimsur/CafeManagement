import React, { useEffect, useState } from 'react';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { TextField, Button, Container, Grid, Typography, Select, MenuItem, FormControl, InputLabel, RadioGroup, FormControlLabel, Radio } from '@mui/material';
import axios from 'axios';

// Validation Schema using Yup
const EmployeeValidationSchema = Yup.object({
  name: Yup.string()
    .min(6, 'Name must be at least 6 characters')
    .max(10, 'Name must not exceed 10 characters')
    .required('Employee name is required'),
  email_address: Yup.string()
    .email('Invalid email format')
    .required('Email address is required'),
  phone_number: Yup.string()
    .matches(/^[89][0-9]{7}$/, 'Phone number must start with 8 or 9 and be 8 digits')
    .required('Phone number is required'),
  gender: Yup.string().required('Gender is required'),
  cafe: Yup.string().required('Assigned cafe is required'),
});

const EmployeeForm = ({ employeeData, cafes, onSubmit }) => {
  const [initialValues, setInitialValues] = useState({
    name: '',
    email_address: '',
    phone_number: '',
    gender: '',
    cafe: '',
  });

  useEffect(() => {
    if (employeeData) {
      setInitialValues({
        name: employeeData.name || '',
        email_address: employeeData.email_address || '',
        phone_number: employeeData.phone_number || '',
        gender: employeeData.gender || '',
        cafe: employeeData.cafe || '',
      });
    }
  }, [employeeData]);

  return (
    <Container>
      <Typography variant="h4">{employeeData ? 'Edit Employee' : 'Add New Employee'}</Typography>
      <Formik
        initialValues={initialValues}
        validationSchema={EmployeeValidationSchema}
        onSubmit={onSubmit}
      >
        {() => (
          <Form>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Field
                  name="name"
                  label="Employee Name"
                  as={TextField}
                  fullWidth
                  variant="outlined"
                  required
                />
                <ErrorMessage name="name" component="div" />
              </Grid>

              <Grid item xs={12}>
                <Field
                  name="email_address"
                  label="Email Address"
                  as={TextField}
                  fullWidth
                  variant="outlined"
                  required
                />
                <ErrorMessage name="email_address" component="div" />
              </Grid>

              <Grid item xs={12}>
                <Field
                  name="phone_number"
                  label="Phone Number"
                  as={TextField}
                  fullWidth
                  variant="outlined"
                  required
                />
                <ErrorMessage name="phone_number" component="div" />
              </Grid>

              <Grid item xs={12}>
                <FormControl component="fieldset" fullWidth>
                  <InputLabel>Gender</InputLabel>
                  <Field name="gender" as={Select} required>
                    <MenuItem value="Male">Male</MenuItem>
                    <MenuItem value="Female">Female</MenuItem>
                  </Field>
                </FormControl>
                <ErrorMessage name="gender" component="div" />
              </Grid>

              <Grid item xs={12}>
                <FormControl component="fieldset" fullWidth>
                  <InputLabel>Assigned Cafe</InputLabel>
                  <Field name="cafe" as={Select} required>
                    {cafes.map((cafe) => (
                      <MenuItem key={cafe.id} value={cafe.id}>
                        {cafe.name}
                      </MenuItem>
                    ))}
                  </Field>
                </FormControl>
                <ErrorMessage name="cafe" component="div" />
              </Grid>

              <Grid item xs={12}>
                <Button type="submit" variant="contained" color="primary">
                  {employeeData ? 'Update Employee' : 'Create Employee'}
                </Button>
              </Grid>
            </Grid>
          </Form>
        )}
      </Formik>
    </Container>
  );
};

export default EmployeeForm;
