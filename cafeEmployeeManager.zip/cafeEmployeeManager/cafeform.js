import React, { useEffect, useState } from 'react';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { TextField, Button, Container, Grid, Typography, Box, Input } from '@mui/material';
import axios from 'axios';

// Validation Schema using Yup
const CafeValidationSchema = Yup.object({
  name: Yup.string()
    .min(6, 'Name must be at least 6 characters')
    .max(10, 'Name must not exceed 10 characters')
    .required('Cafe name is required'),
  description: Yup.string()
    .max(256, 'Description must not exceed 256 characters')
    .required('Cafe description is required'),
  location: Yup.string().required('Location is required'),
  logo: Yup.mixed().nullable(),
});

const CafeForm = ({ cafeData, onSubmit }) => {
  const [initialValues, setInitialValues] = useState({
    name: '',
    description: '',
    location: '',
    logo: null,
  });

  useEffect(() => {
    if (cafeData) {
      setInitialValues({
        name: cafeData.name || '',
        description: cafeData.description || '',
        location: cafeData.location || '',
        logo: cafeData.logo || null,
      });
    }
  }, [cafeData]);

  return (
    <Container>
      <Typography variant="h4">{cafeData ? 'Edit Cafe' : 'Add New Cafe'}</Typography>
      <Formik
        initialValues={initialValues}
        validationSchema={CafeValidationSchema}
        onSubmit={onSubmit}
      >
        {({ setFieldValue }) => (
          <Form>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Field
                  name="name"
                  label="Cafe Name"
                  as={TextField}
                  fullWidth
                  variant="outlined"
                  required
                />
                <ErrorMessage name="name" component="div" />
              </Grid>

              <Grid item xs={12}>
                <Field
                  name="description"
                  label="Description"
                  as={TextField}
                  fullWidth
                  variant="outlined"
                  required
                  multiline
                  rows={4}
                />
                <ErrorMessage name="description" component="div" />
              </Grid>

              <Grid item xs={12}>
                <Field
                  name="location"
                  label="Location"
                  as={TextField}
                  fullWidth
                  variant="outlined"
                  required
                />
                <ErrorMessage name="location" component="div" />
              </Grid>

              <Grid item xs={12}>
                <Input
                  type="file"
                  name="logo"
                  onChange={(event) => setFieldValue('logo', event.currentTarget.files[0])}
                  fullWidth
                />
                <ErrorMessage name="logo" component="div" />
              </Grid>

              <Grid item xs={12}>
                <Button type="submit" variant="contained" color="primary">
                  {cafeData ? 'Update Cafe' : 'Create Cafe'}
                </Button>
              </Grid>
            </Grid>
          </Form>
        )}
      </Formik>
    </Container>
  );
};

export default CafeForm;
